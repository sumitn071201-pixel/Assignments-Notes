class HelloWorld{
	public static void main(String[] args){
       System.out.println("Hello World!!");
	   A ob=new A();
	   ob.method1();
	}

}
class A{
	public void method1(){
		System.out.println("in method1");
	}
}